1. Place the three .csv in the same directory
2. chmod +x script.sh
3. Run ./script.sh

(This will create necessary .csv for deep analysis)
